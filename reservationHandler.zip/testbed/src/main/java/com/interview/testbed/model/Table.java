package com.interview.testbed.model;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class Table {
	private LinkedList<Reservation> reservations;
	private HashMap<Integer, List<Reservation>> resMap;
	private boolean booked;
	
	public Table(LinkedList<Reservation> reservations, HashMap<Integer, List<Reservation>> resMap, boolean booked) {
		this.reservations = reservations;
		this.resMap = resMap;
		this.booked = booked;
	}
	
	public LinkedList<Reservation> getReservations() {
		return reservations;
	}
	public void setReservations(LinkedList<Reservation> reservations) {
		this.reservations = reservations;
	}
	public HashMap<Integer, List<Reservation>> getResMap() {
		return resMap;
	}
	public void setResMap(HashMap<Integer, List<Reservation>> resMap) {
		this.resMap = resMap;
	}
	public boolean isBooked() {
		return booked;
	}
	public void setBooked(boolean booked) {
		this.booked = booked;
	}
	
}