package com.interview.testbed.model;



public class Reservation {

	private int requestID;
	private int receivedTime;
	private int startTime;
	private int duration;
	private int numPeople;
	
	public Reservation(int startTime, int duration) {
		this.startTime = startTime;
		this.duration = duration;
	}
	
	public int getStartTime() {
		return startTime;
	}
	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getRequestID() {
		return requestID;
	}

	public void setRequestID(int requestID) {
		this.requestID = requestID;
	}

	public int getReceivedTime() {
		return receivedTime;
	}

	public void setReceivedTime(int receivedTime) {
		this.receivedTime = receivedTime;
	}

	public int getNumPeople() {
		return numPeople;
	}

	public void setNumPeople(int numPeople) {
		this.numPeople = numPeople;
	}

}