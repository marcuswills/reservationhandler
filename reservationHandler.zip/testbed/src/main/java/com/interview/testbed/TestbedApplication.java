package com.interview.testbed;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import com.google.gson.Gson;
import com.interview.testbed.model.Reservation;
import com.interview.testbed.model.ReservationJson;
import com.interview.testbed.model.Table;

public class TestbedApplication {

	private static Table tableA;
	private static Table tableB;
	private static Table tableC;

	public static void main(String[] args) {
		
		//Didn't get to testing gson out actually
		//read Json file via Gson
		Gson gson = new Gson();
		
		Reader reader;
		try {
			reader = new FileReader("C:\\fileName.json");
			ReservationJson resJson = gson.fromJson(reader, ReservationJson.class);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		List<Reservation> reservations = new ArrayList<Reservation>();
		//instantiate tables
		tableA = new Table(new LinkedList<Reservation>(), new HashMap<Integer, List<Reservation>>(), false);
		tableB = new Table(new LinkedList<Reservation>(), new HashMap<Integer, List<Reservation>>(), false);
		tableC = new Table(new LinkedList<Reservation>(), new HashMap<Integer, List<Reservation>>(), false);
		List<Table> tables = new ArrayList<>();
		tables.add(tableA);
		tables.add(tableB);
		tables.add(tableC);
		//call make reservations with reservations json
		makeReservations(tables, reservations);
	}
	
	public static List<Reservation> makeReservations(List<Table> tables, List<Reservation> reservations) {
		
		for(Reservation res: reservations) {
			//starts at Table A
			for(Table table: tables) {
				//Could build out some smart monitoring to calculate this as we go
				if(table.isBooked()) {
					break;
				}
				
				HashMap<Integer, List<Reservation>> tableResMap = table.getResMap();
				boolean canReserve = true;
				for(int i = res.getStartTime(); i < (res.getStartTime()+res.getDuration()); i++) {
				
					if(tableResMap.containsKey(i)) {
						
						List<Reservation> startReservations = tableResMap.get(Integer.valueOf(res.getStartTime()));
						int counter = 0;
						for(Reservation startRes: startReservations) {
							counter = counter + startRes.getNumPeople();
						}
						if(counter >= 4) {
							canReserve = false;
						}
					}
				}
				if(canReserve) {
					for(int i = res.getStartTime(); i < (res.getStartTime()+res.getDuration()); i++) {
						tableResMap.get(i).add(res);
					}
				}
				
				
			}
		}
		return reservations;
	}

}

