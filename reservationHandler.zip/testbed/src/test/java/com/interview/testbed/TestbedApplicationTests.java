package com.interview.testbed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestbedApplicationTests {

	@Test
	void contextLoads() {
	}

}
